from django.apps import AppConfig


class AppPessoaConfig(AppConfig):
    name = 'app_pessoa'
